document.getElementById("home-signin").addEventListener("click",(e)=>{
    window.location.href = "signIn.html"
})

document.getElementById("home-signup").addEventListener("click",(e)=>{
    window.location.href = "signUp.html"
})